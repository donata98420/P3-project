import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from '@expo/vector-icons/Ionicons';

import { LogInScreen } from '../screens/LogInScreen';
import { MealsScreen } from '../screens/MealsScreen';
import { UploadScreen } from '../screens/UploadScreen';
import { LogOutScreen } from '../screens/LogOutScreen';

const Tab = createBottomTabNavigator();

export function TabNavigator() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === 'LogInScreen') {
              iconName = focused ? 'log-in-outline' : 'log-in-outline';
            } else if (route.name === 'MealsScreen') {
              iconName = focused ? 'fast-food-outline' : 'fast-food-outline';
            } else if (route.name === 'UploadScreen') {
              iconName = focused ? 'add-circle-outline' : 'add-circle-outline';
            } else if (route.name === 'LogOutScreen') {
              iconName = focused ? 'log-out-outline' : 'log-out-outline';
            }

            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: '#FF4081', // Pink color
          tabBarInactiveTintColor: 'gray', // Gray color for inactive icons
        })}
      >
        <Tab.Screen
          name="LogInScreen"
          component={LogInScreen}
          options={{
            title: 'Log In',
            tabBarStyle: {
              padding: 5,
            },
          }}
        />
        <Tab.Screen
          name="MealsScreen"
          component={MealsScreen}
          options={{
            title: 'Meals',
            tabBarStyle: {
              paddingTop: 5,
            },
          }}
        />
        <Tab.Screen
          name="UploadScreen"
          component={UploadScreen}
          options={{
            title: 'Upload',
            tabBarStyle: {
              padding: 5,
            },
          }}
        />
        <Tab.Screen
          name="LogOutScreen"
          component={LogOutScreen}
          options={{
            title: 'Log Out',
            tabBarStyle: {
              padding: 5,
            },
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
