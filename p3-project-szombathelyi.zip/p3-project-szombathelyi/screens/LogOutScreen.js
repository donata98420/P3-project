import React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';

export function LogOutScreen({ route, navigation }) {

  function handleLogInPress() {
    navigation.navigate("Log In");
  }

  function handleUploadPress() {
    navigation.navigate('Upload');
  }

  function handleLogOutPress() {
    navigation.navigate('Log Out');
  }

  function handleMealsPress() {
    navigation.navigate('Meals');
  }

  return (
    <View style={styles.screen}>
      {/* Organic shapes as background */}
      <View style={styles.organicShapes}>
        <View style={styles.organicShape1} />
        <View style={styles.organicShape2} />
      </View>

      <Text style={styles.welcomeText}>Thank's for sharing!</Text>

      <View style={styles.buttonContainer}>
        <Button
          title="LOG IN"
          onPress={() => navigation.navigate("LogInScreen")}
          color="#FF4081"
          style={[styles.button, styles.neomorphism]}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    justifyContent: "center",
    alignItems: 'center',
    backgroundColor: "white"
  },
  organicShapes: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: -1,
  },
  organicShape1: {
    position: 'absolute',
    width: 200,
    height: 200,
    backgroundColor: '#FF4081', 
    borderRadius: 100,
    opacity: 0.3,
    top: -50,
    right: -50,
  },
  organicShape2: {
    position: 'absolute',
    width: 150,
    height: 150,
    backgroundColor: '#42A5F5', 
    opacity: 0.3,
    bottom: -40,
    left: -40,
  },
  welcomeText: {
    fontSize: 30,
    fontWeight: 'bold',
    color: "black",
    marginBottom: 20,
    marginLeft: 5
  },
  buttonContainer: {
    width: '35%', 
    alignSelf: 'flex-start', 
    marginLeft: 90,
    borderRadius: 10,
  },
  button: {
    borderWidth: 0,
  },
  neomorphism: {
    shadowColor: '#000',
    shadowOffset: {
      width: 2,
      height: 2,
    },
    shadowOpacity: 0.5,
    shadowRadius: 5,
    elevation: 5,
  },
});

export default LogOutScreen;
