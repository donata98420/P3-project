import React, { useState } from 'react';
import {
  View,
  Image,
  Text,
  Button,
  StyleSheet,
  TextInput,
  ScrollView,
} from 'react-native';

export function UploadScreen({ route, navigation }) {
  const [title, setTitle] = useState('');
  const [area, setArea] = useState('');
  const [ingredients, setIngredients] = useState('');
  const [instructions, setInstructions] = useState('');
  const [image, setImage] = useState('');

  const sendRequest = async () => {
    try {
      const response = await fetch('https://webhook.site/51fdc835-3ec8-45fe-8f82-2758062b19d4', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title: title,
          area: area,
          ingredients: ingredients,
          instructions: instructions,
          image: image,
        }),
      });

      if (response.ok) {
        // Reset fields if successful
        setTitle('');
        setArea('');
        setIngredients('');
        setInstructions('');
        setImage('');
      } else {
        console.error('Failed to send request');
      }
    } catch (error) {
      console.error('Error sending request:', error);
    }
  };

  return (
    <View style={styles.screen}>
      {/* Organic shapes as background */}
      <View style={styles.organicShapes}>
        <View style={styles.organicShape1} />
        <View style={styles.organicShape2} />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={styles.welcomeText}>Have a recipe? Share!</Text>

        <View style={styles.inputWrapper}>
          <TextInput
            style={[styles.input, styles.neomorphism]}
            onChangeText={setTitle}
            value={title}
            placeholder="Title of a meal"
          />
        </View>

        <View style={styles.inputWrapper}>
          <TextInput
            style={[styles.input, styles.neomorphism]}
            onChangeText={setArea}
            value={area}
            placeholder="Area (ex. Indian)"
          />
        </View>

        <View style={styles.inputWrapper}>
          <TextInput
            style={[styles.input, styles.neomorphism]}
            onChangeText={setIngredients}
            value={ingredients}
            placeholder="Ingredients and measures"
          />
        </View>

        <View style={styles.inputWrapper}>
          <TextInput
            style={[styles.input, styles.neomorphism]}
            onChangeText={setInstructions}
            value={instructions}
            placeholder="Instructions"
          />
        </View>

        <View style={styles.inputWrapper}>
          <TextInput
            style={[styles.input, styles.neomorphism]}
            onChangeText={setImage}
            value={image}
            placeholder="Upload image here"
          />
        </View>

        <View style={styles.space} />

        <View style={styles.buttonContainer}>
          <Button
            style={[styles.button, styles.neomorphism, { width: '100%' }]}
            title="Post"
            onPress={sendRequest}
            color="#FF4081" 
          />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: 'white', 
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  organicShapes: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: -1,
  },
  organicShape1: {
    position: 'absolute',
    width: 200,
    height: 200,
    backgroundColor: '#FF4081', 
    borderRadius: 100,
    opacity: 0.3,
    top: -50,
    right: -50,
  },
  organicShape2: {
    position: 'absolute',
    width: 150,
    height: 150,
    backgroundColor: '#42A5F5', 
    borderRadius: 75,
    opacity: 0.3,
    bottom: -40,
    left: -40,
  },
  welcomeText: {
    fontSize: 30,
    fontWeight: 'bold',
    color: 'black',
    marginBottom: 20,
    marginLeft: 33,
  },
  inputWrapper: {
    marginBottom: 15,
    width: '80%',
  },
  input: {
    height: 40,
    width: '100%',
    borderWidth: 1,
    padding: 10,
    borderRadius: 0,
    backgroundColor: 'white',
  },
  buttonContainer: {
    width: '35%',
    alignSelf: 'flex-start',
    marginLeft: 35,
    borderRadius: 0,
  },
  space: {
    height: 20,
  },
  neomorphism: {
    shadowColor: '#000',
    shadowOffset: {
      width: 2,
      height: 2,
    },
    shadowOpacity: 0.5,
    shadowRadius: 5,
    elevation: 5,
  },
});

export default UploadScreen;
