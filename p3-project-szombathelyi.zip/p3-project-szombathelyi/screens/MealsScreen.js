import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  Button,
  StyleSheet,
  ActivityIndicator,
  FlatList,
  Image,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { FontAwesome } from '@expo/vector-icons'; 

export function MealsScreen({ route, navigation }) {
  const [isLoading, setLoading] = useState(true);
  const [meal, setMeal] = useState([]);

  const getMeal = async () => {
    try {
      const response = await fetch(
        'https://www.themealdb.com/api/json/v1/1/search.php?s=chicken'
      );
      const json = await response.json();
      setMeal(json.meals);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getMeal();
  }, []);

  function handleLogInPress() {
    navigation.navigate('Log In');
  }
  function handleUploadPress() {
    navigation.navigate('Upload');
  }
  function handleLogOutPress() {
    navigation.navigate('Log Out');
  }

  function handleMoreInfo(item) {
    navigation.navigate('MealDetailScreen', { meal: item });
  }

  return (
    <ScrollView style={styles.screen}>
      <View style={styles.organicShapeContainer}>
        {/* Organic shapes as background */}
        <View style={styles.organicShapes}>
          <View style={styles.organicShape1} />
          <View style={styles.organicShape2} />
        </View>

        <View style={styles.cartContainer}>
          <Text style={styles.menuText}>Chicken's menu</Text>
          <TouchableOpacity
            onPress={() => {
              navigation.navigate('CartScreen');
            }}
          >
            <FontAwesome name="shopping-cart" size={24} color="white" />
          </TouchableOpacity>
        </View>

        <View style={styles.container}>
          {isLoading ? (
            <ActivityIndicator style={styles.loadingIndicator} />
          ) : (
            <FlatList
              data={meal}
              keyExtractor={({ idMeal }, index) => idMeal}
              renderItem={({ item }) => (
                <View style={[styles.itemWrapper, styles.neomorphism]}>
                  <Image style={styles.image} source={{ uri: item.strMealThumb }} />

                  <View style={styles.detailsContainer}>
                    <Text style={styles.title}>{item.strMeal}</Text>
                    <Text style={styles.price}>$5.99</Text>
                    <Button
                      title="Add to Cart"
                      onPress={() => handleMoreInfo(item)}
                      color="#FF4081"
                      style={styles.addToCartButton}
                    />
                  </View>
                </View>
              )}
            />
          )}
        </View>
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>ChickMick restaurant</Text>
        <Text style={styles.footerText}>Lincoln Street 810</Text>
        <Text style={styles.footerText}>12 345 Miami, California</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#F5F5F5', 
  },
  organicShapeContainer: {
    position: 'relative',
  },
  organicShapes: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: -1,
  },
  organicShape1: {
    position: 'absolute',
    width: 180,
    height: 180,
    backgroundColor: '#FF4081', 
    borderRadius: 100,
    opacity: 0.3,
    top: -50,
    right: -50,
  },
  organicShape2: {
    position: 'absolute',
    width: 150,
    height: 150,
    backgroundColor: '#42A5F5', 
    borderRadius: 75,
    opacity: 0.3,
    bottom: -40,
    left: -40,
  },
  cartContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between', 
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 15,
    backgroundColor: 'black', 
  },
  menuText: {
    color: 'black',
    fontSize: 18,
    fontWeight: 'bold',
  },
  container: {
    paddingVertical: 20,
    paddingHorizontal: 15,
  },
  loadingIndicator: {
    marginTop: 20,
  },
  itemWrapper: {
    marginBottom: 20,
    backgroundColor: 'white', 
    borderRadius: 10,
  },
  image: {
    width: '100%',
    height: 200,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  detailsContainer: {
    padding: 20,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  price: {
    fontSize: 20,
    marginBottom: 15,
  },
  addToCartButton: {
    marginTop: 10, 
  },
  footer: {
    marginTop: 20,
    paddingHorizontal: 15,
    paddingBottom: 20,
    marginHorizontal: 15,
  },
  footerText: {
    fontSize: 16,
    marginBottom: 5,
    marginTop: 15,
    textAlign: 'left',
  },
  neomorphism: {
    shadowColor: '#000',
    shadowOffset: {
      width: 2,
      height: 2,
    },
    shadowOpacity: 0.5,
    shadowRadius: 5,
    elevation: 5,
    backgroundColor: 'white', 
  },
});

export default MealsScreen;
